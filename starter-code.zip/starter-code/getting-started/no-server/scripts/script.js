window.addEventListener('load', function() {
  document.getElementById('para').innerHTML = 'Hello from JavaScript!';
});