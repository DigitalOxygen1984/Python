from django.apps import AppConfig


class JokesConfig(AppConfig):
    name = 'jokes'
