from add_nums_with_return import add_nums

total = add_nums(1, 2, 3, 4, 5)
print(total)