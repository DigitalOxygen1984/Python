# Say Hello to the World (twice!)
print("Hello, world!")
print("Hello again, world!")