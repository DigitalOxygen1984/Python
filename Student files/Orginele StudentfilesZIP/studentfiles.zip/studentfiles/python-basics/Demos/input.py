def main():
    today = input("What day is it? ")
    print("Wow! Today is ", today, "? Awesome!", sep="")

main()