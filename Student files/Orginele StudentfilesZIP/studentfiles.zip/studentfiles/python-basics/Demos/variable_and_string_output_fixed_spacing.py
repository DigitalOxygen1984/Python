def main():
    today = "Monday"
    print("Today is ", today, ".", sep="")

main()