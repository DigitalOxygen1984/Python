# Say Hello to the World
print("Hello, world!")