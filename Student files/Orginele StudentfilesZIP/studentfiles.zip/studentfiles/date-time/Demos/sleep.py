import time

for i in range(10, 0, -1):
    print(i)
    time.sleep(.5)

print('Blast off!')