with open('my_files/yoda.txt', 'w') as f:
    f.write('Powerful you have become.')