# ZeroDivisionError
try:
    1/0
except Exception as e:
    print(type(e))
    print(e, '\n')

# ValueError
try:
    pass # code that creates exception
except Exception as e:
    print(type(e))
    print(e, '\n')

# NameError
try:
    pass # code that creates exception
except Exception as e:
    print(type(e))
    print(e, '\n')

# FileNotFoundError
try:
    pass # code that creates exception
except Exception as e:
    print(type(e))
    print(e, '\n')

# ImportError
try:
    pass # code that creates exception
except Exception as e:
    print(type(e))
    print(e, '\n')

# TypeError
try:
    pass # code that creates exception
except Exception as e:
    print(type(e))
    print(e, '\n')

# AttributeError
try:
    pass # code that creates exception
except Exception as e:
    print(type(e))
    print(e, '\n')

# StopIteration
try:
    pass # code that creates exception
except Exception as e:
    print(type(e))
    print(e, '\n')

# KeyError
try:
    pass # code that creates exception
except Exception as e:
    print(type(e))
    print(e, '\n')