try:
    1/0
except:
    print('Something really bad just happened! Oh no, oh no, oh no!')
    raise