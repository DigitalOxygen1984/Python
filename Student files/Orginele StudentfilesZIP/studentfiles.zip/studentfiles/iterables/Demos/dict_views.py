grades = {
    "English": 97,
    "Math": 93,
    "Global Studies": 85,
    "Art": 74,
    "Music": 86
}

gradepoints = grades.values()
print("Grade points:", gradepoints)

grades["Art"] = 87
print("Grade points:", gradepoints)