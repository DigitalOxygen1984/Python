import random

def remove_random(the_list):
    pass # replace this with your code

def main():
    colors = ['red', 'blue', 'green', 'orange']
    # Your code here

main()