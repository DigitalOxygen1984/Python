print(min(2, 1, 3)) # 1
print(min(3.14, -1.5, -300)) # -300
print(max(2, 1, 3)) # 3
print(max(3.14, -1.5, -300)) # 3.14