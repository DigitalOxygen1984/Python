phrase = "Monty Python"

first_letter = phrase[0] # [M]onty Python
print(first_letter)

last_letter = phrase[-1] # Monty Pytho[n]
print(last_letter)

fifth_letter = phrase[4] # Mont[y] Python
print(fifth_letter)

third_letter_from_end = phrase[-3] # Monty Pyt[h]on
print(third_letter_from_end)